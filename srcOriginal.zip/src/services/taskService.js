const Task = require('../models/Task');

// Create a task
async function createTask(data) {
  const task = new Task({
    ...data,
    createdBy: data.createdBy,
    signedBy: {
      id: data.createdBy,
      name: data.creatorName || 'Unknown',
      signedAt: new Date()
    },
    revisionHistory: [{
      updatedBy: {
        id: data.createdBy,
        name: data.creatorName || 'Unknown',
        role: data.role || 'nurse'
      },
      updatedAt: new Date(),
      changes: 'Task created'
    }]
  });

  await task.save();
  return task;
}

// Get all tasks assigned to a specific patient
async function getTasksForPatient(patientId) {
  return await Task.find({ patient: patientId, isDeleted: false });
}

// Get all tasks assigned to a specific role and user
async function getTasksForUser(role, userId) {
  return await Task.find({ role, $or: [{ assignedTo: userId }, { createdBy: userId }], isDeleted: false });
}

// Delete a task if the user is the one who created it
async function deleteTask(taskId, userId) {
  const task = await Task.findById(taskId);
  if (!task) throw new Error('Task not found');
  if (task.createdBy.toString() !== userId.toString()) {
    throw new Error('You are not authorized to delete this task');
  }
  await task.deleteOne();
  return true;
}

module.exports = {
  createTask,
  getTasksForPatient,
  getTasksForUser,
  deleteTask
};
